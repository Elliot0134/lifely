# Tiptap – Pro License for Extensions, UI Components and Templates

## 1. Object of License

1.1. These License Terms ("License Terms") consists of the terms and conditions governing the perpetual grant of use rights and use of the software products Tiptap Pro Extensions, Tiptap Pro UI Components and Tiptap Pro Templates ("Software") provided by Tiptap GmbH ("Licensor") by a user of the Software acting as entrepreneurs within the meaning of section 14 German Civil Code (BGB) ("End User") for the provision of the Software. Consumers as defined in section 13 German Civil Code (BGB) are not offered the use of the Software and the conclusion of these License Terms.
1.2. These License Terms are a legally binding agreement between the Licensor and all End Users. Other terms and conditions, in particular those of the End User, do not apply.

## 2. Grant of Use Rights

2.1. Upon full payment of the license fee, the Licensor will grant the End User the non-exclusive, non-sublicensable, non-transferable, unlimited in time to use the Software in accordance with this License Terms for their use within the scope of their business operations.
2.2. The End User's right of use includes the installation of the Software as well as loading, displaying, and running the installed Software, storing the Software in the memory for the purpose of executing it and the further development of the Software. The End User may use and/or integrate the Software in other software products and create derivative works of the Software.
2.3. The End User may distribute such further developments and the created derivative works of the Software in accordance with the following:
2.3.1. The End User may not distribute the Software, any parts of it, any modifications, or derivative works of the Software as a standalone product, but only as part of another software product or application.
2.3.2. The End User may not make the Software or parts of it available under a license that supersedes or negates the effect of this License Terms.
2.3.3. The End User may only distribute or otherwise make available the Software as part of another software product or application if these License Terms are agreed with users of software products or applications, which include the Software. In particular, the End User must include a copy of this License in any distribution or otherwise making available of the Software as part of another software product or application.
2.4. The Licensor does not grant the End User any further rights to the Software.
2.5. Using the Software in the name or for the account of a third party who is not the contractual partner is also considered unauthorized use of the Software. It is irrelevant here whether the third party pays the End User a fee for use or not.

## 3. Defects of the Software

3.1. The End User shall notify the Licensor of any defects without delay, reproducibly stating how and under what circumstances the error or defect occurs. The End User will actively support the Licensor in the search for the defect and, in particular, provide all further necessary documents and data which the Licensor requires for the analysis and elimination of the defect. If, after examination of a notice of defect, it turns out that the defect did not occur within the Licensor's area of responsibility, the Licensor may charge the End User for the costs of the examination at the respective applicable prices. This does not apply if the End User could not have recognized that the fault was not within the Licensor's area of responsibility when exercising the necessary diligence.
3.2. The End User must inspect the Software for obvious defects immediately upon receipt and notify the Licensor of any such defects without delay; otherwise, a warranty for these defects is excluded. The same applies if such a defect is discovered later. Section 377 of the German Commercial Code shall apply.
3.3. In the event of a defect, the Licensor is initially entitled to subsequent performance, i.e. at his own discretion to rectification of the defect or replacement delivery. As part of the replacement delivery, the End User shall, if necessary, accept a new version of the Software, unless this leads to unreasonable impairments. The End User's right to reduce the purchase price or withdraw from the contractual relationship regarding software purchase concluded with the Licensor at his discretion in the event that the repair or replacement delivery fails twice remains unaffected. The End User is not entitled to withdrawal in the case of insignificant defects.
3.4. The End User is not entitled to any defect rights insofar as the End User modifies the Software or has it modified by third parties, unless the End User proves that this modification is not the cause of the defect.

## 4. Liability

4.1. The Licensor will be liable pursuant to statutory rules (a) in the event of intentional and grossly negligent damage; (b) in the event of injury to life, body or health; (c) under the provisions of the German Product Liability Act; and (d) within the scope of any guarantee assumed.
4.2. For simple negligent breach of a contractual duty which is material to achieve the purpose of the contract, and which the End User relies on and is entitled to rely on being fulfilled (material contractual obligations), the Licensor's liability will be limited in terms of the amount to the foreseeable damage and damage typical for such contracts. Otherwise, the Licensor's liability is precluded.
4.3. The above liability restrictions also apply accordingly in favor of the Licensor's vicarious agents.
4.4. In the event of loss of data, the Licensor will only be liable for the time and effort required to restore the data, subject to proper data backup by the End User.

## 5. Confidentiality

5.1 The End User is required to maintain confidentiality in relation to all information arising in connection with these License Terms and their execution.
5.2 The End User is under obligation to ensure its employees also maintain confidentiality towards third parties.
5.3 This obligation does not apply to generally known documents and common knowledge, or documents and knowledge with which the End User was already acquainted when they were received, without the supplier being sworn to secrecy, or that are developed by the End User without use being made of any confidential documents or knowledge. This obligation also does not apply if the End User is required to disclose information by law or by official or court order.
5.4 Confidential information may only be forwarded to third parties after prior written consent from the Licensor.

## 6. Final Provisions

6.1. These License Terms are governed by the law of the Federal Republic of Germany. The UN Convention on Contracts for the International Sale of Goods (CISG) does not apply. The courts at the Licensor's registered office will have sole jurisdiction for all disputes regarding rights and duties arising from these License Terms, including their validity. However, the Licensor is entitled to file a claim against the End User at its general place of jurisdiction.
6.2. The End User is not entitled to assign or transfer rights or claims arising from the contractual relationship between the parties to third parties without the Licensor's prior written consent.
6.3. Amendments and additions to these License Terms require at least text form to be valid. This also applies to any amendment to this form clause.
6.4. If any provision(s) of these License Terms are or become invalid or unenforceable, this will not affect the validity of the other provisions of these License Terms. The parties will replace the invalid or unenforceable provision with a provision which is enforceable and practicable under statute and in economic terms reflects as closely as possible the essence and purpose of the invalid or unenforceable provision. Should these License Terms be incomplete, the parties will conclude an agreement with the content they would have agreed upon had they been aware of the omission when concluding these License Terms.
